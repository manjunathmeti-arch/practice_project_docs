```
kubectl apply -f capi-azurekubeadm.yaml
```