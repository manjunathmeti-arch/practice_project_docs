```
clusterctl get kubeconfig capi-azure > capi-azure.kubeconfig
```