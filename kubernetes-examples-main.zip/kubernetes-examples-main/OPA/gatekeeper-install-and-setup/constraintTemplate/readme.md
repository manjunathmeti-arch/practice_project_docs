The Constrain Template is the rule/policy that you want to configure for your environment. It's a template, so you can use it across multiple constraints.

For example, there's a Rego policies in the constraint template in this directory that ensures no one can utilize the `latest` tag of a container image.