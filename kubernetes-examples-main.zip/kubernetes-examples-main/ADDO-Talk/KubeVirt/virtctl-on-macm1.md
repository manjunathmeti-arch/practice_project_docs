Download `virtctl` for ARM: https://github.com/kubevirt/kubevirt/releases/tag/v1.1.0-alpha.0

Run it via the terminal. For example, to start a new VM with the CLI, run the following:

```
./virtctl-v1.1.0-alpha.0-darwin-arm64 start deployvm
```

You can put it into your $PATH as well.