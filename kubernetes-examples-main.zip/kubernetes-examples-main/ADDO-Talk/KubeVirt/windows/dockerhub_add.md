Download ISO: https://info.microsoft.com/ww-landing-windows-server-2019.html

```
docker build -t adminturneddevops/winkube/w2k9_iso:sep2020 .
```

```
docker tag docker_id adminturneddevops/winkube:latest
```

```
docker push adminturneddevops/winkube:latest
```