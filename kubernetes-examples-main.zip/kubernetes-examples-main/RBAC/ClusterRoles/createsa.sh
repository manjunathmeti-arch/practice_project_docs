# Service Account
kubectl create sa mikeuser

# Get Service Account
kubectl get sa mikeuser