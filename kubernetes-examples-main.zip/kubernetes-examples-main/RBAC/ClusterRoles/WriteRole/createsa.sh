# Service Account
kubectl create sa podcreator

# Get Service Account
kubectl get sa podcreator