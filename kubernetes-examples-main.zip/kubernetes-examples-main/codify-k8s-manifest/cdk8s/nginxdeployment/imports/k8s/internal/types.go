package internal
import (
	"github.com/cdk8s-team/cdk8s-core-go/cdk8s/v2"
)
type Type__cdk8sApiObject = cdk8s.ApiObject
