1. Create the EKS cluster

See how within the EKS cluster creation, the resource exists for the EBS CSI driver.

2. Show the storageClass information

3. Create the PVC witin the PVC folder

4. Run the code for `nginx.yaml`.

5. Delete the Pod

6. Create the PV by itself

7. Connect the DB to an RDS instance